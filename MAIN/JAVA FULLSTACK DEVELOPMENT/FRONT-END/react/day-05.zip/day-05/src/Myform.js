import React, { useState } from 'react';

export default function Myform(props) {

  const [name, setName] = useState(props.uName);

  function getName(event) {
    setName(event.target.value);
  }

  return (
    <div>
      <input type="text" placeholder="Enter Name" onChange={getName} />

      <h1>{name}</h1>
    </div>
  );
}