
import React, { useState } from "react";

function Form(props) {

  const [name, setName] = useState();
  const [age, setAge] = useState();

  function getName(e) {
    setName(e.target.value);
  }

  function getAge(a) {
    setAge(a.target.value);
  }

  function getData() {
    props.acceptData(name, age)
  }

  return (
    <section>
      <div>
        <label>Name:</label>
        <input type="text" placeholder="Enter Name" onChange={getName} />
      </div>
      <div>
        <label>Age:</label>
        <input type="text" placeholder="Enter Age" onChange={getAge} />
      </div>
      <div>
        <button type="button" onClick={getData}>Click</button>
      </div>
    </section>
  );
}
export default Form;
