import React, { useState } from 'react';

import './App.css';
// import Myform from './Myform';
import Form from './Form';

function App() {

  const empData = [
    // { name: 'Jack', age: 23 }
  ];

  const [data, setData] = useState(empData);
  // const userName = "Jack";

  function getData(x, y) {
    console.log('Inside App.Js');
    console.log(x, y);
    // setData({ name: x, age: y });
    setData(previousState => [...previousState, { name: x, age: y }]);

    // [{name: name, age: age}]


  }

  return (
    <section>
      <Form acceptData={getData} />

      {/* <Myform uName={userName} /> */}

      {
        console.log(data)
      }
    </section>
  );
}

export default App;
