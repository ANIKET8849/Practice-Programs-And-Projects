import React, { useState } from 'react';

export default function Form(props) {

  const [name, setName] = useState("");
  const [age, setAge] = useState();
  const [valid, setValid] = useState(true);

  function getName(event) {
    setName(event.target.value);
  }

  function getAge(event) {
    setAge(event.target.value);
  }

  function sendData() {
    // console.log(name, age);


    if (!name && !age) {
      setValid(false);
    } else {
      props.acceptData(name, age);
    }

  }


  return (
    <React.Fragment>
      <div>
        <input type="text" placeholder="Enter Name" onChange={getName}
          style={{ borderColor: valid === true ? "green" : "red" }}
        />
      </div>
      <div>
        <input type="text" placeholder="Enter Age" onChange={getAge}
          style={{ borderColor: valid === true ? "green" : "red" }}
        />
      </div>
      <div>
        <button type="button" onClick={sendData}>Click</button>
      </div>
    </React.Fragment>
  );
}