import React, { useState } from 'react';
import Form from './Form';
import styled from 'styled-components';

import './App.css';

export default function App() {

  const prevData = [
    { name: 'Hemant', age: '23' }
  ];

  const [emp, setEmp] = useState(prevData);

  function getDataFrmForm(x, y) {
    // console.log("Inside App");
    // console.log({ name: x, age: y });
    setEmp(previousData => [...previousData, { name: x, age: y }]);
  }


  const Component = styled.button`
    color: white;
    background-color: black;
    border: none;
    margin: 20px 0;
    width: 200px;
    height: 50px;
    font-size: 18px;
    transition: .5s all linear;

    &:hover {
      background-color: tomato;
    }

    @media (min-width: 992px){
      background-color: purple;
      width: 400px;
    }
  ` ;

  return (
    <>

      <Component>
        Click
      </Component>

      <Form acceptData={getDataFrmForm} />

      <table width="100%" border="1" cellpadding="10" cellspacing="0">
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          {
            emp.map((e) => {
              return (
                <tr>
                  <td>{e.name}</td>
                  <td>{e.age}</td>
                </tr>
              );
            })
          }
        </tbody>
      </table>
      {/* {
        console.log(emp)
      } */}
    </>
  );
}
