import React, { useState } from 'react';
import axios from 'axios';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import './App.css';

function App() {

  const [movie, setMovie] = useState([]);

  function getData() {

    const opt = {
      method: 'GET',
      url: 'https://unogs-unogs-v1.p.rapidapi.com/search/titles',
      params: {
        order_by: 'date',
        type: 'movie'
      },
      headers: {
        'X-RapidAPI-Key': '8bdde5ba95msh61b05230ea6f9f0p1abbaajsn6835de44cc16',
        'X-RapidAPI-Host': 'unogs-unogs-v1.p.rapidapi.com'
      }
    };

    axios(opt).then((response) => {
      setMovie(response.data.results);
    }).catch((error) => {
      console.log(error);
    });
  }

  return (
    <React.Fragment>
      <section className="container mt-5">
        <button type="button" className="btn btn-lg btn-success" onClick={getData}>Get Data</button>
      </section>

      <hr />

      <section className="container">
        <div className="row">
          {
            movie.map((m, key) => {
              return (
                <figure className="col-md-6 col-lg-3" key={key}>
                  <img src={m.poster} alt={m.title} />
                  <figcaption>
                    <p><b>Movie Title: </b> {m.title}</p>
                    <p><b>Year: </b>{m.year} <span className="ps-5"><b>Rating</b> {m.rating}</span></p>
                    <p><b>Synopsis:</b> {m.synopsis}</p>
                    <button type="button" className="btn btn-success">Watch Movie</button>
                  </figcaption>
                </figure>
              );
            })
          }
        </div>
      </section>

      {/* {
        console.log(movie)
      } */}
    </React.Fragment>
  );
}

export default App;
