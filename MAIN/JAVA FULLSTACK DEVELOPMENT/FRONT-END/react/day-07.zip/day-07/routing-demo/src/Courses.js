import React from 'react';

export default function Courses() {
  return (
    <>
      <section className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="innerContent h-100">
          <p>Hello I'm</p>
          <h1 className="display2">Courses Section</h1>
        </div>
      </section>
    </>
  );
}