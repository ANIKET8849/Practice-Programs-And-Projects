import React from 'react';

export default function Contact() {
  return (
    <>
      <section className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="innerContent h-100">
          <p>Hello I'm</p>
          <h1 className="display2">Contact Section</h1>
        </div>
      </section>
    </>
  );
}