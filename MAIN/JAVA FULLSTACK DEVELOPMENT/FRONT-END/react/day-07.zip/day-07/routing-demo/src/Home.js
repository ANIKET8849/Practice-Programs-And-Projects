import React from 'react';

export default function Home() {
  return (
    <>
      <section className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="innerContent h-100">
          <p>Hello I'm</p>
          <h1 className="display2">Home Section</h1>
        </div>
      </section>
    </>
  );
}