import React from 'react';
import { Link } from 'react-router-dom';

export default function Nav() {
  return (
    <nav className="d-flex justify-content-center">
      {/* <ul className="nav">
        <li className="nav-item">
          <a className="nav-link" href="./Home">Home</a>
          </li>
        <li className="nav-item">
          <a className="nav-link" href="./Courses">Courses</a>
          </li>
        <li className="nav-item">
          <a className="nav-link" href="./About">About</a>
          </li>
        <li className="nav-item">
          <a className="nav-link" href="./Download">Download</a>
          </li>
        <li className="nav-item">
          <a className="nav-link" href="./Contact">Contact</a>
          </li>
      </ul> */}

      <ul className="nav">
        <li className="nav-item">
          <Link className="nav-link" to="./Home">Home</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="./Courses">Courses</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="./About">About</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="./Download">Download</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="./Contact">Contact</Link>
        </li>
      </ul>
    </nav>
  );
}