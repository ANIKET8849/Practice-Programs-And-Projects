import React from 'react';

import '../node_modules/bootstrap/dist/css/bootstrap.css';
import '../node_modules/bootstrap/dist/js/bootstrap.bundle';

import { BrowserRouter, Routes, Route } from 'react-router-dom';

import './App.css';
import Nav from './Nav';
import Home from './Home';
import Courses from './Courses';
import About from './About';
import Download from './Download';
import Contact from './Contact';

function App() {
  return (
    <React.Fragment>
      <BrowserRouter>
        <Nav />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/about" element={<About />} />
          <Route path="/download" element={<Download />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </BrowserRouter>
    </React.Fragment>
  );
}

export default App;
