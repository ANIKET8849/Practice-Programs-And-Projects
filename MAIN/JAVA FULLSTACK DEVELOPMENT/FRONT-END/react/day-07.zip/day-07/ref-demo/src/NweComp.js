import React, { useState, useRef } from 'react';

export default function NweComp() {

  const [userName, setUserName] = useState();
  const ele = useRef();
  const inputValue = useRef();

  function changeStyle() {
    ele.current.style.background = "#ffff00";
  }

  function getName() {
    setUserName(inputValue.current.value);
    inputValue.current.style.borderBottom = "2px solid green";
    console.log(inputValue.current.value);
  }

  return (
    <>
      <h1>Hello</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, exercitationem?</p>
      <p ref={ele}>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Esse commodi repellendus aliquam vero similique vel voluptatem ratione voluptatibus ex, quisquam molestias error, neque quia! Sed, tempora molestias! Provident, optio delectus.</p>
      <hr />

      <div style={{ "margin": "20px 0" }}>
        <input type="text" placeholder="Enter Data" ref={inputValue} />
      </div>

      <button type="button" onClick={changeStyle}>Change Style</button>
      <button type="button" onClick={getName}>Get Name</button>

      <h1>{userName}</h1>
    </>
  );
}

