import React from 'react';

import './App.css';
import NweComp from './NweComp';

function App() {
  return (
    <React.Fragment>
      <NweComp />
    </React.Fragment>
  );
}

export default App;
