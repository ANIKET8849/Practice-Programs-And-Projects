$(document).ready(function(){
    $("#btn").click(function(){
        $(".header").css({
            "color":"red","background-color":"yellow","font-style":"italic","font-size":"50px","font-family":"san-serif","letter-spacing":"5px"
        });
    })
});