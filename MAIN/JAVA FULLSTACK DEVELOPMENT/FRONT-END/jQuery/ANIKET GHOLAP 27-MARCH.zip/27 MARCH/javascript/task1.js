$(document).ready(function(){
    $("#btn").click(function(){
        $(".header").css({
            "color":"red","background-color":"yellow","font-family":"san-serif","letter-spacing":"5px"
        });
        $(".div1").css({
            "size":"400px","border":"2px solid grey","padding":"50px","background-color":"blue","border-radius":"50px"
        });
    })
});