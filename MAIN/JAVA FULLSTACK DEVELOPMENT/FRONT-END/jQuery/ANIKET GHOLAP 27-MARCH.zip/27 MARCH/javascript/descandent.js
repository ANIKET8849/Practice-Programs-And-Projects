$(document).ready(function(){
    $("#btn").click(function(){
        $(".div1 h1").css({
            "color":"red","background-color":"yellow"
        });
    })
});