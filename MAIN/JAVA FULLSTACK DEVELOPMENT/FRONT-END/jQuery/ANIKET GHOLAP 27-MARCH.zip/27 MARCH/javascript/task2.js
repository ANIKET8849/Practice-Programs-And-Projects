$(document).ready(function(){
    $("#btn").click(function(){
        $(".header").css({
            "color":"red","background-color":"yellow","letter-spacing":"5px"
        });
        $(".div1").css({
            "margin":"50px","border":"5px solid red","border-radius":"100px","height":"400px","width":"900px"
        });
    })
});