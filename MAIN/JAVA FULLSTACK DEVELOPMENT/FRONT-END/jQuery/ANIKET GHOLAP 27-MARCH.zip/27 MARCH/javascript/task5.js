$(document).ready(function(){
    $("#btn").click(function(){
        $(".header").css({
            "color":"red","background-color":"yellow","letter-spacing":"5px","font-size":"20px","line-height":"2"
        });
        $(".div1").css({
            "margin":"50px","border":"1px solid red","border-radius":"60px","height":"500px","width":"900px","padding":"50px"
        });
    })
});