$(document).ready(function(){
    $("#btn").click(function(){
        $(".header").css({
            "color":"white","background-color":"red","letter-spacing":"5px"
        });
        $(".div1").css({
            "margin":"50px","border":"3px solid red","border-radius":"30px","height":"400px","width":"900px","padding":"50px"
        });
    })
});