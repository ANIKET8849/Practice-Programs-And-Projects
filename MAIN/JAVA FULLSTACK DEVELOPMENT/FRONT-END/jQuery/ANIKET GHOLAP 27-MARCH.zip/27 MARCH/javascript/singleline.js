$(document).ready(function(){
    $("#btn").click(function(){
        $(".header").css("color","red")
    })
});