$(document).ready(function(){
    $("input").keyup(function(){
        $(this).css({
            "background-color":"red"
        })
    })
})