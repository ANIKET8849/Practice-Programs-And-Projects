$(document).ready(function(){
    $('.h1').blur(function(){
        $('.span').css({
            'transition': '2s',
            'font-size': '40px',
            'color': 'grey'
        })
    })
})