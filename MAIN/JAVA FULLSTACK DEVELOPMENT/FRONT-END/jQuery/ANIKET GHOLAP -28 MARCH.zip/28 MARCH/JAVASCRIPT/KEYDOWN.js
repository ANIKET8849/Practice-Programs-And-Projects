$(document).ready(function(){
    $("input").keydown(function(){
        $(this).css({
            "background-color":"yellow"
        })
    })
})