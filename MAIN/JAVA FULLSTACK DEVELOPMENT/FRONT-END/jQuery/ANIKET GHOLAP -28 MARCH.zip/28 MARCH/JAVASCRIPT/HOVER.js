$(document).ready(function(){
    $(".div1").hover(function(){
        $(this).css({
            "background-color":"red","transition":"3sec"
        })
    })
})