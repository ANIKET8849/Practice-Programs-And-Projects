$(document).ready(function(){
    $("input").keypress(function(){
        $(this).css({
            "background-color":"grey"
        })
    })
})