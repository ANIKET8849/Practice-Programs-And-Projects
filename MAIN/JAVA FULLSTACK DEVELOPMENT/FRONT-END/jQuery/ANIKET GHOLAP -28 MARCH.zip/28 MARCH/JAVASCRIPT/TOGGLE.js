$(document).ready(function(){
    $("#btn").click(function(){
        $("h1").toggle();
    })
})