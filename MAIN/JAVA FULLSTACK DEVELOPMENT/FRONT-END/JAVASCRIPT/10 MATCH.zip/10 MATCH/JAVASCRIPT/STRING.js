let data1="Many of life’s failures are people who did not realize how close they were to success when they gave up."
let data2="my self is ANIKET"


document.write(data2+" "+data1+"<br>");

document.write(data2.length+"<br>");

document.write(data1.indexOf('done')+"<br>");

document.write(data1.lastIndexOf('from')+"<br>");

document.write(data1.substring(16,20)+"<br>");

document.write(data1.substr(20)+"<br>");

document.write(data2.toUpperCase()+"<br>");

document.write(data2.toLowerCase()+"<br>");