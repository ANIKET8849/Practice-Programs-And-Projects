document.write(Math.PI+"<br>");

document.write(Math.abs(-10)+"<br>");

document.write(Math.cbrt(27)+"<br>");

document.write(Math.ceil(5.5)+"<br>");

document.write(Math.floor(5.5)+"<br>");

document.write(Math.round(5.5)+"<br>");

document.write(Math.trunc(525.5)+"<br>");

document.write(Math.max(10,15,20,25)+"<br>");

document.write(Math.min(10,15,20,25)+"<br>");