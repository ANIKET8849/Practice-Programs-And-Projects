let d=new Date();

// NEW DATE 
document.write(d.toLocaleString()+"<br>");

// GET HOURS 
document.write(d.getHours()+"<br>");

// GET MINUTES 
document.write(d.getMinutes()+"<br>");

// GET SECONDS 
document.write(d.getSeconds()+"<br>");

// GET MILISECONDS 
document.write(d.getMilliseconds()+"<br>");

// GET MONTH 
document.write(d.getMonth()+"<br>");

// GET FULL YEAR 
document.write(d.getFullYear()+"<br>");

// GET TIME 
document.write(d.getTime()+"<br>");