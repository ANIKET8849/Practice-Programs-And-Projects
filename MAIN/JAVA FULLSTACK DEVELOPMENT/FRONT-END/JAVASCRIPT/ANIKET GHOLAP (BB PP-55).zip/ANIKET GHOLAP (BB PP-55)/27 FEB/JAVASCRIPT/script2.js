var num1=parseInt(prompt("Enter First Number"));
var num2=parseInt(prompt("Enter second Number"));
if(num1>num2){
    document.write(num1+" IS THE LARGE NUMBER");
}
else{
    document.write(num2+" IS THE LARGE NUMBER");
}