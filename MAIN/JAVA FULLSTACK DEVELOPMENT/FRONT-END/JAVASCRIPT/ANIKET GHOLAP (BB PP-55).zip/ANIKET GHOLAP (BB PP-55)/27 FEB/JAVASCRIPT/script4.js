var a=parseInt(prompt("Enter The Year"));
if(a%4==0){
    document.write(a+" THIS YEAR IS LEAP YEAR");
}
else{
    document.write(a+" THIS YEAR IS NOT A LEAP YEAR");
}