var num1=parseInt(prompt("Enter Any Number"));
if(num1%2==0){
    document.write("THE NUMBER IS EVEN NUMBER");
}
else{
    document.write("THE NUMBER IS ODD NUMBER");
}