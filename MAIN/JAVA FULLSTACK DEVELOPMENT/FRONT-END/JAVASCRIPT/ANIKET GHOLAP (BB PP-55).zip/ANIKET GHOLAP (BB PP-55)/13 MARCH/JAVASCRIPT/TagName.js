    //    ONCLICK 

// function change(){
//     document.getElementsByTagName("div")[0].style.backgroundColor="red";
// }

        // ONCHANGE 
// function red(){
//      document.getElementsByTagName("div")[0].style.backgroundColor="red";
// }
// function purple(){
//     document.getElementsByTagName("div")[0].style.backgroundColor="purple";
// }