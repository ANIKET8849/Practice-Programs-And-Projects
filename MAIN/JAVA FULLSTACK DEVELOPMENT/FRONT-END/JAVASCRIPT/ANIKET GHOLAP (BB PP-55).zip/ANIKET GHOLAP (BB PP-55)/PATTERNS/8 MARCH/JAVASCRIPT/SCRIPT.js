let i,j;
for(i=1;i<=5;i++){
    for(j=1;j<=i;j++){
        document.write("* ");
    }
    document.write("<br>");
}