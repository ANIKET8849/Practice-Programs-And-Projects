var num1=10,num2=20,divide=num2/num1;
console.log("10/20 = "+divide);