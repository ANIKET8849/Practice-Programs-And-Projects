// function sum()
// {
//     let a=10;
//     let b=20;
//     document.write(a+b);
// }
// sum();


var a=parseInt(prompt("Enter first value"));
var b=parseInt(prompt("Enter second value"));

function sum()
{
    document.write("addition "+(a+b)+"<br>");
}
sum();

function sub()
{
    document.write("substration "+(a-b)+"<br>");
}
sub();


function mul()
{
    document.write("multiplication "+(a*b)+"<br>");
}
mul();