var num1=parseInt(prompt("enter first number"));
var num2=parseInt(prompt("enter second number"));
const sum=(a,b)=>{
    document.write("addition "+(a+b)+"<br>")
}
sum(num1,num2);

const sub=(a,b)=>{
    document.write("substration "+(a-b)+"<br>")
}
sub(num1,num2);

const mul=(a,b)=>{
    document.write("multiplication "+(a*b)+"<br>")
}
mul(num1,num2);