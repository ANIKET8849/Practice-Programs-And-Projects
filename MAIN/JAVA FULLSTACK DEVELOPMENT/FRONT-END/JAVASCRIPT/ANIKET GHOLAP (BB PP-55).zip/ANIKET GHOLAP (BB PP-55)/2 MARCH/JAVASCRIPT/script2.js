function sum(a,b)
{
    document.write("addition "+(a+b)+"<br>");
}
sum(10,20);


function sub(a,b)
{
    document.write("substration "+(a-b)+"<br>");
}
sub(10,20);


function mul(a,b)
{
    document.write("multiplication "+(a*b)+"<br>");
}
mul(10,20);