var num1=parseInt(prompt("Enter first number"));
var num2=parseInt(prompt("Enter second number"));

function sum(a,b)
{
    document.write("addition "+(a+b)+"<br>");
}
sum(num1,num2);


function sub(a,b)
{
    document.write("substration "+(a-b)+"<br>");
}
sub(num1,num2);


function mul(a,b)
{
    document.write("multiplication "+(a*b)+"<br>");
}
mul(num1,num2);