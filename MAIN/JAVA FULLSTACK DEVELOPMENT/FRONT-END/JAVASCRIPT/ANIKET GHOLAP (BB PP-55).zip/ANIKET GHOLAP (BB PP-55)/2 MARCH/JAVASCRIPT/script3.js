function sum(a,b)
{
    return a+b;
}
let a=sum(10,20);
document.write(a+"<br>");


function sub(a,b)
{
    return a-b;
}
let b=sub(10,20);
document.write(b+"<br>");



function mul(a,b)
{
    return a*b;
}
let c=mul(10,20);
document.write(c+"<br>");