let colors=["Red","Blue","Green","purple","voilet"];
document.write(colors+"<br>");

// push 
colors.push("pink")
document.write(colors+"<br>");

// pop 
colors.pop();
document.write(colors+"<br>");

// length 
document.write(colors.length+"<br>");

// sort 
document.write(colors.sort()+"<br>");


// reverse 
document.write(colors.reverse()+"<br>");

// shift 
document.write(colors.shift()+"<br>");

// unshift 
colors.unshift("orange")
document.write(colors+"<br>");

// join 
document.write(colors.join("@")+"<br>");

