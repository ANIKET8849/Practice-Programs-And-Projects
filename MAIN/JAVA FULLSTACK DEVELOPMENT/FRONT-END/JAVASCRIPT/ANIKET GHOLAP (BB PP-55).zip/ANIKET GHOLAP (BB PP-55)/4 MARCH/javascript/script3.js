function div(x){

    x.style.fontSize="30px"
}