function para(x){
    x.style.background="red"
}