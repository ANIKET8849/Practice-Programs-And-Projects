function img1(){
    document.getElementById("img1").style.background=URL(IMAGES/kristin-wilson-alEMgpX6oo8-unsplash.jpg)
}

function img2(){
    document.getElementById("img2").style.background=URL(IMAGES/martin-katler-wx-XBLK1bWA-unsplash.jpg)
}
