let number1=parseFloat(prompt("Enter first number"));
let number2=parseFloat(prompt("Enter second number"));
console.log(number1+number2);