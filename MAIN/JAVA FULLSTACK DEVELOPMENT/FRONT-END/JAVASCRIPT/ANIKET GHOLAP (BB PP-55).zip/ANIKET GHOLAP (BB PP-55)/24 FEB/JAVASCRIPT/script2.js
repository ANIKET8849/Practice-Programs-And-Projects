// console.log(prompt("Enter your name?"));
// let num1=parseInt(prompt("Enter first number"));
// let num2=parseInt(prompt("Enter second number"));
// console.log("addition ="+(num1+num2));
// let num1=parseFloat(prompt("Enter first number"));
// let num2=parseFloat(prompt("Enter second number"));
// console.log("addition = "+(num1+num2));
// console.warn("this is warning");
// confirm("do you want to save changes?");
// alert("this is alert");
// console.log(typeof 34);
"use strict"

let  number=10;
console.log(number);