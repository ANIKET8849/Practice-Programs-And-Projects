function on(){
    document.getElementById("name").style.background="yellow";
}

function key(){
    document.getElementById("name2").style.background="green";
}

function events(){
    document.getElementById("name3").style.background="red";
}