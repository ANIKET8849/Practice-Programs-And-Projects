let x=1;

function div(){
    document.getElementById("demo").innerHTML = x+=1;
}