function paragraph(){
    window.print();
}