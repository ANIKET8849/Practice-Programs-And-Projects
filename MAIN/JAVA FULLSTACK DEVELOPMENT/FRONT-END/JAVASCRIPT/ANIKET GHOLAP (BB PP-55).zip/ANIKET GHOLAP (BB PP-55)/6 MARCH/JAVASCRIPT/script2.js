function redirect(){
    window.location.href="https://www.w3schools.com/jsref/event_onload.asp";
}