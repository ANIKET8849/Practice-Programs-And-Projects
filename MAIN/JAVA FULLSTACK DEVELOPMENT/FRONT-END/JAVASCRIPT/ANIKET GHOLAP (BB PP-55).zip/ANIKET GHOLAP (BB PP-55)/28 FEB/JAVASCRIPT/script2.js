let a=50;
do{
    document.write(a+"<br>");
    a--;
}
while(a>=1);