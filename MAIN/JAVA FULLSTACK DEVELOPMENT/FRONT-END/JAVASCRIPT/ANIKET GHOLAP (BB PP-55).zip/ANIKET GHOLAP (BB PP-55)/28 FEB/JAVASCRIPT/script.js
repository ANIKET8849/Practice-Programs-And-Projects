let a=10;
while(a>=1){
    document.write(a+"<br>");
    a--
}