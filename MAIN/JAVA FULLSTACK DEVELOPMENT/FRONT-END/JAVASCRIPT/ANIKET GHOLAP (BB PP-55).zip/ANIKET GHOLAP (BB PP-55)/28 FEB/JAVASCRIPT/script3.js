for(let a=100; a>=1; a--){
    document.write(a+"<br>");
}