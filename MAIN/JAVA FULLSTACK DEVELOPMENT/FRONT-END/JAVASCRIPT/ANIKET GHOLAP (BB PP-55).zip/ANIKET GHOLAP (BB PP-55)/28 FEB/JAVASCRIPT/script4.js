for(let a=1; a<=20; a++){
    if(a%2==0){
        document.write(a+" <br>")
    }
}

// let a=1;
// while(a<=20){
//     document.write(a+"even number")
//     a++;
// }