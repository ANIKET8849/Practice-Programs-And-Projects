let a=1;
let sum=0;
for(a ; a<=10; a++){
    document.write(a+"<br>")
    sum = sum + a;
}
document.write("<br>"+sum);