for(let a=1; a<=20; a++){
    if(a%2!=0){
        document.write(a+" <br>")
    }
}