document.getElementById("div2").innerText="amogoe"; 




document.getElementsByClassName("div4")[0].innerHTML="<li>Home</li>" ; 

document.getElementsByClassName("div4")[1].innerHTML="<li>About</li>" ; 

document.getElementsByClassName("div4")[2].innerHTML="<li>Services</li>" ; 

document.getElementsByClassName("div4")[3].innerHTML="<li>Contact</li>" ; 




document.getElementsByClassName("head")[0].innerText="Hello,I am "; 

document.getElementsByClassName("head1")[0].innerText="a Front End Developer"; 

document.getElementsByClassName("head3")[0].innerHTML="<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic? Perferendis aliquid a possimus.</P>" 

document.getElementsByClassName("button-1")[0].innerText="create journey"; 

document.getElementsByClassName("set")[0].innerHTML="<h3>services</h3>"; 

document.getElementsByClassName("set1")[0].innerHTML="<h1>Skill-set</h1>";  

document.getElementsByClassName("set1")[0].style.color="red"; 




document.getElementsByClassName("skill2")[0].innerText="onsectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic?"


document.getElementsByClassName("skill5")[0].innerText="onsectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic?"


document.getElementsByClassName("skill7")[0].innerText="onsectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic?"


document.getElementsByClassName("skill9")[0].innerText="onsectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic?"


document.getElementsByClassName("skill11")[0].innerText="onsectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic?"

document.getElementsByClassName("skill13")[0].innerText="onsectetur, adipisicing elit. Minus minima expedita, distinctio temporibus corrupti, qui error facilis consectetur voluptates illum neque dolores necessitatibus fugit omnis hic?"


document.getElementsByClassName("connect")[0].innerText="Connect with me";

document.getElementsByClassName("connect")[0].style.color="red";

document.getElementsByClassName("hello01")[0].innerText="Stop connected";

