package com.sm.Onetomany;

import java.util.Set;

public class Actor {

	private int aid;
	private String actorname;
	
	private Set<Movies> movies;
	
	public Actor(String actorname, int aid, Set<Movies> movies) {
		super();
		this.actorname = actorname;
		this.aid = aid;
		this.movies = movies;
	}
	
	public String getActorname() {
		return actorname;
	}
	public void setActorname(String actorname) {
		this.actorname = actorname;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	
	public Set<Movies> getMovies() {
		return movies;
	}
	public Actor() {
	}
	public void setMovies(Set<Movies> movies) {
		this.movies = movies;
	}
}
