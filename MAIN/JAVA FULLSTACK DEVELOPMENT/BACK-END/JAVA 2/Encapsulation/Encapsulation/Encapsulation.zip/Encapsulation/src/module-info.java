/**
 * 
 */
/**
 * @author DELL
 *
 */
module Encapsulation {
}