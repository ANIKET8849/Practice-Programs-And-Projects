package com.org;

public class GettersSetters {
	private String name3;
	//private int age;
	
	public String getName() {
		return name3;
	}
	
	public void setName(String name2) {
		this.name3=name2;
	}
}
