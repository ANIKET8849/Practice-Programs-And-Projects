#include<iostream>

using namespace std;

int main()
{
	int year;
	bool option = false;
	
	
	cout << "Enter any year: ";
	cin >> year;
	
	if(option == true)
		cout << "Hi";
	else
		cout << "Hello";
	
//	if(year%4 == 0)
//		cout << year << " is a Leap Year";
//	else
//		cout << year << " is not a Leap Year";
	return 0;
}
