#include<iostream>

using namespace std;

int main()
{
	int no1=100, no2=25, sum;
	
	no1 = 10;
	no2 = 5;
	
	sum = no1 + no2;
	
	cout << no1 << " + " << no2 << " = " << sum;
	return 0;
}
