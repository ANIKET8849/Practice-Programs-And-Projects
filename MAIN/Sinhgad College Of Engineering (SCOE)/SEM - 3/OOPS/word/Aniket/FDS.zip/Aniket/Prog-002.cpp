#include<iostream>

using namespace std;

int main()
{
	int no1, no2, sum;
	
	cout << "Enter two numbers: ";
	cin >> no1 >> no2;
	
	sum = no1 + no2;
	
	cout << no1 << " + " << no2 << " = " << sum;
	return 0;
}
